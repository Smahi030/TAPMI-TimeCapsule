// Fill these in from Supabase: Project Settings > API.
// The anon key is meant to be public; the database rules protect the data.
// Leave both empty to run the page as a browser-only prototype.
window.CAPSULE_CONFIG = {
  supabaseUrl: "",      // e.g. "https://abcdefghijkl.supabase.co"
  supabaseAnonKey: ""   // the long "anon public" key
};
