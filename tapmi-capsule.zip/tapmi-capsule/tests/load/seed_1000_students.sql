-- 1,000 students, ~50 items each, realistic sharing
\timing off
set client_min_messages = warning;
insert into auth.users(id,email)
  select ('00000000-0000-4000-8000-' || lpad(g::text,12,'0'))::uuid, 'student'||g||'@learner.manipal.edu' from generate_series(1,1000) g;
update profiles p set full_name = 'Student '||substr(p.email,8,4),
  section_id = (array['core-1','core-2','core-3','core-4','core-5','msm','ib','bkfs','hr','ai-ds'])[1 + (hashtext(p.id::text) & 2147483647) % 10];
insert into profile_committees
  select p.id, c.id from profiles p cross join lateral (select id from committees order by md5(p.id::text||id) limit 1 + (hashtext(p.email) & 3)) c;
-- items: 50 per person, sealed over the past year
insert into capsule_items (id, owner_id, owner_name, kind, caption, section_id, storage_path, thumb_path, opens_at, sealed_at)
select gen_random_uuid(), p.id, p.full_name,
       case when g % 5 < 2 then 'photo'::capsule_kind else 'note' end,
       'Memory '||g, p.section_id,
       case when g % 5 < 2 then p.id||'/'||g||'.jpg' end,
       case when g % 5 < 2 then p.id||'/'||g||'_t.jpg' end,
       '2028-05-01 00:00+05:30', now() - (random()*365)*interval '1 day'
  from profiles p cross join generate_series(1,50) g;
insert into capsule_contents select id, 'A note written during the MBA, number '||caption from capsule_items where kind='note';
insert into storage.objects (bucket_id, name, metadata)
  select 'capsules', storage_path, '{"mimetype":"image/jpeg","size":"350000"}'::jsonb from capsule_items where kind='photo'
  union all
  select 'capsules', thumb_path, '{"mimetype":"image/jpeg","size":"35000"}'::jsonb from capsule_items where kind='photo';
-- 30% shared with the section, 15% with one of the owner's clubs
insert into capsule_shares (item_id, section_id) select id, section_id from capsule_items where random() < .30;
insert into capsule_shares (item_id, committee_id)
  select i.id, (select pc.committee_id from profile_committees pc where pc.profile_id = i.owner_id limit 1)
    from capsule_items i where random() < .15;
analyze;
select (select count(*) from profiles) people, (select count(*) from capsule_items) items,
       (select count(*) from capsule_shares) shares, (select count(*) from storage.objects) files;
