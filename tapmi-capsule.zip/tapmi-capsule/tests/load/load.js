// Load test against PostgREST (the same API layer Supabase runs).
// usage: node load.js <scenario: open|seal> <virtual users> <seconds>
const crypto = require('crypto');
const SECRET = process.argv[5] || process.env.JWT_SECRET, API = 'http://127.0.0.1:3001';
const [,, scen, VUS, SECS] = process.argv; const vus = +VUS, secs = +SECS;
const b64u = b => Buffer.from(b).toString('base64url');
function jwt(sub) { const h = b64u(JSON.stringify({ alg: 'HS256', typ: 'JWT' })), p = b64u(JSON.stringify({ sub, role: 'authenticated', aud: 'authenticated', exp: Math.floor(Date.now() / 1000) + 3600 }));
  return h + '.' + p + '.' + crypto.createHmac('sha256', SECRET).update(h + '.' + p).digest('base64url'); }
const uid = i => '00000000-0000-4000-8000-' + String(1 + (i % 1000)).padStart(12, '0');
const lat = {}, errs = {}, done = []; let n = 0;
async function rpc(tok, name, body, tag) {
  const t = performance.now();
  try {
    const r = await fetch(API + '/rpc/' + name, { method: 'POST', headers: { Authorization: 'Bearer ' + tok, 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) });
    const txt = await r.text(); (lat[tag] ??= []).push(performance.now() - t); n++;
    if (!r.ok) { const k = tag + ' ' + r.status + ' ' + (JSON.parse(txt).message || '').slice(0, 50); errs[k] = (errs[k] || 0) + 1; }
    return r.ok ? JSON.parse(txt) : null;
  } catch (e) { errs[tag + ' network ' + e.message] = (errs[tag + ' network ' + e.message] || 0) + 1; }
}
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function vu(i, end) {
  const tok = jwt(uid(i));
  if (scen === 'burst') {                        // everyone hits the site in the same second, once
    await Promise.all([rpc(tok, 'my_profile', {}, 'my_profile'), rpc(tok, 'batch_stats', {}, 'batch_stats')]);
    await rpc(tok, 'my_capsule', { p_limit: 60 }, 'my_capsule'); done.push(Date.now()); return;
  }
  while (Date.now() < end) {
    if (scen === 'open') {                       // a full page load on opening night
      await Promise.all([rpc(tok, 'my_profile', {}, 'my_profile'), rpc(tok, 'batch_stats', {}, 'batch_stats')]);
      const page = await rpc(tok, 'my_capsule', { p_limit: 60 }, 'my_capsule');
      if (page && page.length === 60) await rpc(tok, 'my_capsule', { p_limit: 60, p_before: page[59].sealed_at, p_before_id: page[59].id }, 'my_capsule (page 2)');
    } else {                                     // sealing notes, retried with the same id
      const id = crypto.randomUUID(), body = { p_note: 'load test ' + id, p_share_section: Math.random() < .3, p_id: id };
      await rpc(tok, 'seal_note', body, 'seal_note');
      await sleep(1600 + Math.random() * 800);
    }
  }
}
(async () => {
  const end = Date.now() + secs * 1000, t0 = Date.now();
  await Promise.all(Array.from({ length: vus }, (_, i) => vu(i, end)));
  const el = (Date.now() - t0) / 1000;
  if (done.length) { done.sort((a, b) => a - b); console.log(`\nall ${done.length} pages loaded; half within ${((done[done.length >> 1] - t0) / 1000).toFixed(1)}s, last at ${((done[done.length - 1] - t0) / 1000).toFixed(1)}s`); }
  console.log(`\n${scen}: ${vus} people at once for ${secs}s -> ${n} requests, ${(n / el).toFixed(0)} req/s`);
  for (const [k, a] of Object.entries(lat)) { a.sort((x, y) => x - y); const q = f => a[Math.min(a.length - 1, Math.floor(a.length * f))].toFixed(0);
    console.log(`  ${k.padEnd(20)} n=${String(a.length).padStart(6)}  median ${q(.5).padStart(4)} ms  p95 ${q(.95).padStart(5)} ms  p99 ${q(.99).padStart(5)} ms`); }
  console.log('  errors:', Object.keys(errs).length ? errs : 'none');
})();
