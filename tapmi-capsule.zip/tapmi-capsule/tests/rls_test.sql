-- Security tests for the TAPMI Time Capsule schema.
-- Each check raises an exception if the rule is broken.
-- Cast: Asha (Core 3; ARC, BrandScan), Ravi (Core 3), Meera (IB; ARC), Dev (IB).
\set ON_ERROR_STOP on
set client_min_messages = warning;

create or replace function pg_temp.as_user(uid uuid) returns void language plpgsql as $$
begin perform set_config('request.jwt.claim.sub', coalesce(uid::text,''), false); end $$;
create or replace function pg_temp.ok(cond boolean, label text) returns void language plpgsql as $$
begin
  if not coalesce(cond,false) then raise exception 'FAIL: %', label; end if;
  raise notice 'pass: %', label;
end $$;
set client_min_messages = notice;

-- ------------------------------------------------------------------
-- 1. Sign-up domain rule
-- ------------------------------------------------------------------
do $$ begin
  insert into auth.users(id,email) values ('00000000-0000-0000-0000-00000000000a','asha@learner.manipal.edu');
  insert into auth.users(id,email) values ('00000000-0000-0000-0000-00000000000b','ravi@learner.manipal.edu');
  insert into auth.users(id,email) values ('00000000-0000-0000-0000-00000000000c','meera@learner.manipal.edu');
  insert into auth.users(id,email) values ('00000000-0000-0000-0000-00000000000d','dev@learner.manipal.edu');
end $$;
select pg_temp.ok((select count(*)=4 from public.profiles), 'profiles created for college emails');

do $$ begin
  begin
    insert into auth.users(email) values ('outsider@gmail.com');
    raise exception 'FAIL: gmail sign-up was allowed';
  exception when sqlstate 'P0001' then
    if sqlerrm like 'FAIL%' then raise; end if;
    raise notice 'pass: non-college email rejected';
  end;
end $$;

-- ------------------------------------------------------------------
-- 2. Profiles
-- ------------------------------------------------------------------
set role authenticated;
select pg_temp.as_user('00000000-0000-0000-0000-00000000000a');
do $$ begin
  begin perform public.seal_note('too early'); raise exception 'FAIL: sealed without a profile';
  exception when others then if sqlerrm like 'FAIL%' then raise; end if; raise notice 'pass: must finish profile before sealing'; end;
end $$;
select public.complete_profile('Asha Rao','core-3', array['arc','brandscan','not-a-committee']);
select pg_temp.ok((select section_id='core-3' from public.profiles), 'Asha profile saved');
select pg_temp.ok((select count(*)=2 from public.profile_committees), 'unknown committee ignored');
select pg_temp.ok((select count(*)=1 from public.profiles), 'Asha sees only her own profile');
do $$ begin
  begin update public.profiles set section_id='ib'; raise exception 'FAIL: direct profile update allowed';
  exception when insufficient_privilege then raise notice 'pass: no direct profile writes'; end;
end $$;

select pg_temp.as_user('00000000-0000-0000-0000-00000000000b');
select public.complete_profile('Ravi Nair','core-3');
do $$ begin
  begin perform public.complete_profile('Ravi Nair','ib'); raise exception 'FAIL: section hop allowed';
  exception when others then if sqlerrm like 'FAIL%' then raise; end if; raise notice 'pass: section is fixed once set'; end;
end $$;
select public.complete_profile('Ravi Nair','core-3', array['lime']);
select pg_temp.ok((select count(*)=1 from public.profile_committees), 'clubs can still be updated');
select public.complete_profile('Ravi Nair','core-3');

select pg_temp.as_user('00000000-0000-0000-0000-00000000000c');
select public.complete_profile('Meera Shah','ib', array['arc']);
select pg_temp.as_user('00000000-0000-0000-0000-00000000000d');
select public.complete_profile('Dev Kumar','ib');

-- ------------------------------------------------------------------
-- 3. Sealing and sharing (as Asha)
-- ------------------------------------------------------------------
select pg_temp.as_user('00000000-0000-0000-0000-00000000000a');
select public.seal_note('Midnight maggi after the Waves finals.', null, 'swathi', 'waves');
select public.seal_note('Section secret for Core 3.', 'For Core 3', 'nc', null, true);
select pg_temp.ok((select bool_and(opens_at = '2028-05-01 00:00:00+05:30') from public.capsule_items), 'opens_at comes from settings');
select pg_temp.ok((select count(*)=1 from public.capsule_items where event_id='waves'), 'event tag saved');
select pg_temp.ok((select bool_and(owner_name='Asha Rao') from public.capsule_items), 'owner name recorded for shared cards');
do $$ begin
  begin perform public.seal_note('x', null, null, 'not-an-event'); raise exception 'FAIL: unknown event accepted';
  exception when others then if sqlerrm like 'FAIL%' then raise; end if; raise notice 'pass: unknown event rejected'; end;
end $$;
do $$ begin
  begin perform public.seal_note('x', null, null, null, false, array['cct']); raise exception 'FAIL: shared with a club she is not in';
  exception when others then if sqlerrm like 'FAIL%' then raise; end if; raise notice 'pass: can only share with your own clubs'; end;
end $$;
select pg_temp.ok((select count(*)=2 from public.capsule_items), 'failed share left no half-sealed item behind');

do $$ begin
  begin insert into public.capsule_items(owner_id,kind,opens_at) values (auth.uid(),'note',now()-interval '1 day');
        raise exception 'FAIL: direct insert with a past open date allowed';
  exception when insufficient_privilege then raise notice 'pass: cannot insert items directly (no early open dates)'; end;
end $$;
do $$ begin
  begin update public.capsule_items set opens_at = now() - interval '1 day';
        raise exception 'FAIL: owner moved open date';
  exception when insufficient_privilege then raise notice 'pass: cannot change open date'; end;
end $$;
do $$ begin
  begin insert into public.capsule_shares(item_id, section_id) select id, 'ib' from public.capsule_items limit 1;
        raise exception 'FAIL: wrote a share directly';
  exception when insufficient_privilege then raise notice 'pass: cannot add shares directly'; end;
end $$;

-- photo shared with ARC
insert into storage.objects(bucket_id,name,metadata)
  values ('capsules','00000000-0000-0000-0000-00000000000a/p1.jpg','{"mimetype":"image/jpeg","size":"20480"}');
select public.seal_photo('00000000-0000-0000-0000-00000000000a/p1.jpg','ARC group photo','sus-block', null, null, null, false, array['arc']);
select pg_temp.ok((select bytes=20480 and mime_type='image/jpeg' from public.capsule_items where kind='photo'), 'photo metadata recorded');
select pg_temp.ok((select count(*)=2 from public.capsule_shares), 'two shares recorded (Core 3 note, ARC photo)');
do $$ begin
  begin perform public.seal_photo('00000000-0000-0000-0000-00000000000b/x.jpg');
        raise exception 'FAIL: sealed a photo from someone else''s folder';
  exception when others then if sqlerrm like 'FAIL%' then raise; end if; raise notice 'pass: cannot seal another user''s photo'; end;
end $$;
do $$ begin
  begin perform public.seal_photo('00000000-0000-0000-0000-00000000000a/missing.jpg');
        raise exception 'FAIL: sealed a photo that was never uploaded';
  exception when others then if sqlerrm like 'FAIL%' then raise; end if; raise notice 'pass: photo must exist before sealing'; end;
end $$;
do $$ begin
  begin insert into storage.objects(bucket_id,name) values ('capsules','00000000-0000-0000-0000-00000000000b/sneaky.jpg');
        raise exception 'FAIL: uploaded into another user''s folder';
  exception when insufficient_privilege then raise notice 'pass: uploads limited to own folder'; end;
end $$;

-- ------------------------------------------------------------------
-- 4. Before opening day
-- ------------------------------------------------------------------
select pg_temp.ok((select count(*)=3 from public.capsule_items), 'owner sees her 3 sealed items');
select pg_temp.ok((select count(*)=0 from public.capsule_contents), 'owner cannot read note text before opening');
select pg_temp.ok((select count(*)=0 from storage.objects), 'owner cannot read photo before opening');
select pg_temp.ok((select count(*)=3 and bool_and(note_text is null) from public.my_capsule()), 'my_capsule: owner gets 3 sealed cards, no note text');
select pg_temp.ok((select (my_profile()->>'my_items')::int=3 and my_profile()->'committees' = '["arc","brandscan"]'::jsonb), 'my_profile returns clubs and item count');
select pg_temp.ok((with a as (select * from public.my_capsule(2)), b as (select * from public.my_capsule(2,
    (select sealed_at from a order by sealed_at, id limit 1), (select id from a order by sealed_at, id limit 1)))
  select (select count(*) from a)=2 and (select count(*) from b)=1 and not exists (select 1 from a join b using (id))),
  'my_capsule pages without repeats');

select pg_temp.as_user('00000000-0000-0000-0000-00000000000b');
select pg_temp.ok((select count(*)=1 from public.capsule_items), 'Core 3 classmate gets the section note as a sealed card');
select pg_temp.ok((select owner_name='Asha Rao' from public.capsule_items), 'and sees who it is from');
select pg_temp.ok((select count(*)=1 from public.capsule_shares), 'and which group it was shared with');
select pg_temp.ok((select count(*)=0 from public.capsule_contents), 'but cannot read it before opening');
select pg_temp.ok((select count(*)=1 and bool_and(shared_with = array['section:core-3'] and note_text is null and owner_name='Asha Rao')
  from public.my_capsule()), 'my_capsule: classmate gets the shared card, still sealed');
do $$ begin delete from public.capsule_items; raise notice 'pass: classmate delete affects nothing'; end $$;

select pg_temp.as_user('00000000-0000-0000-0000-00000000000c');
select pg_temp.ok((select count(*)=1 and bool_and(kind='photo') from public.capsule_items), 'ARC member in another section gets the ARC photo card');
select pg_temp.ok((select count(*)=0 from storage.objects), 'but cannot open the photo before opening');

select pg_temp.as_user('00000000-0000-0000-0000-00000000000d');
select pg_temp.ok((select count(*)=0 from public.capsule_items), 'student in neither group sees nothing');
select pg_temp.ok((select count(*)=0 from public.my_capsule()), 'my_capsule: outsider gets nothing');

select pg_temp.as_user('00000000-0000-0000-0000-00000000000a');
select pg_temp.ok((select count(*)=3 from public.capsule_items), 'Asha''s items survived the classmate delete');

reset role;
set role anon;
select pg_temp.as_user(null);
do $$ begin
  begin perform count(*) from public.capsule_items; raise exception 'FAIL: signed-out visitor could query items';
  exception when insufficient_privilege then raise notice 'pass: signed-out visitor cannot query items at all'; end;
end $$;
select pg_temp.ok((select sum(items)=3 from public.batch_stats()), 'batch counts visible without content');
do $$ begin
  begin perform * from public.my_capsule(); raise exception 'FAIL: signed-out visitor called my_capsule';
  exception when insufficient_privilege then raise notice 'pass: signed-out visitor cannot call my_capsule'; end;
end $$;
select pg_temp.ok((select count(*)=10 from public.sections), 'sections readable signed out');
select pg_temp.ok((select count(*)=7 from public.events), 'events readable signed out');
reset role;

-- late joiner: a new Core 3 student signs up after the share
insert into auth.users(id,email) values ('00000000-0000-0000-0000-00000000000e','late@learner.manipal.edu');
set role authenticated;
select pg_temp.as_user('00000000-0000-0000-0000-00000000000e');
select public.complete_profile('Late Joiner','core-3');
select pg_temp.ok((select count(*)=1 from public.capsule_items), 'someone joining Core 3 later still gets the section note');
reset role;

-- ------------------------------------------------------------------
-- 5. Opening day (admin moves the date into the past)
-- ------------------------------------------------------------------
select public.admin_set_open_date(now() - interval '1 minute');
set role authenticated;
select pg_temp.as_user('00000000-0000-0000-0000-00000000000a');
do $$ begin
  begin perform public.admin_set_open_date(now()); raise exception 'FAIL: user could change open date';
  exception when insufficient_privilege then raise notice 'pass: only admin can move opening day'; end;
end $$;
select pg_temp.ok((select count(*)=2 from public.capsule_contents), 'owner reads her notes after opening');
select pg_temp.ok((select count(*)=1 from storage.objects), 'owner can read her photo after opening');

select pg_temp.as_user('00000000-0000-0000-0000-00000000000b');
select pg_temp.ok((select note_text like 'Section secret%' from public.capsule_contents), 'Core 3 classmate reads the section note');
select pg_temp.ok((select count(*)=1 from public.capsule_contents), 'and only that note');
select pg_temp.ok((select note_text like 'Section secret%' from public.my_capsule()), 'my_capsule includes the note text once open');
select pg_temp.ok((select count(*)=0 from storage.objects), 'but not the ARC photo');

select pg_temp.as_user('00000000-0000-0000-0000-00000000000c');
select pg_temp.ok((select count(*)=1 from storage.objects), 'ARC member opens the ARC photo');
select pg_temp.ok((select count(*)=0 from public.capsule_contents), 'but not the Core 3 note');

select pg_temp.as_user('00000000-0000-0000-0000-00000000000d');
select pg_temp.ok((select count(*)=0 from public.capsule_items), 'outsider still sees nothing after opening');

-- ------------------------------------------------------------------
-- 6. Deleting your own item
-- ------------------------------------------------------------------
select pg_temp.as_user('00000000-0000-0000-0000-00000000000a');
delete from public.capsule_items where kind='note' and id not in (select item_id from public.capsule_shares);
select pg_temp.ok((select count(*)=2 from public.capsule_items), 'owner deleted her own private note');
reset role;
delete from storage.objects where name = '00000000-0000-0000-0000-00000000000a/p1.jpg';
delete from public.capsule_items where storage_path = '00000000-0000-0000-0000-00000000000a/p1.jpg';
select pg_temp.ok((select count(*)=0 from storage.objects) and (select count(*)=1 from public.capsule_shares),
  'deleting the photo removes it from everyone it was shared with');

-- ------------------------------------------------------------------
-- 7. Built for load: retries, throttle, thumbnails, stats cache
-- ------------------------------------------------------------------
set role authenticated;
select pg_temp.as_user('00000000-0000-0000-0000-00000000000a');
select public.seal_note('Retry me', null, null, null, false, '{}', '11111111-0000-0000-0000-000000000001');
select public.seal_note('Retry me', null, null, null, false, '{}', '11111111-0000-0000-0000-000000000001');
select pg_temp.ok((select count(*)=1 from public.capsule_items where id='11111111-0000-0000-0000-000000000001'), 'a retried seal does not create a duplicate');
select pg_temp.as_user('00000000-0000-0000-0000-00000000000b');
do $$ begin
  begin perform public.seal_note('hijack', null, null, null, false, '{}', '11111111-0000-0000-0000-000000000001');
        raise exception 'FAIL: reused someone else''s item id';
  exception when others then if sqlerrm like 'FAIL%' then raise; end if; raise notice 'pass: cannot reuse another person''s item id'; end;
end $$;

select pg_temp.as_user('00000000-0000-0000-0000-00000000000a');
insert into storage.objects(bucket_id,name,metadata) values
  ('capsules','00000000-0000-0000-0000-00000000000a/p2.jpg','{"mimetype":"image/jpeg","size":"300000"}'),
  ('capsules','00000000-0000-0000-0000-00000000000a/p2_t.jpg','{"mimetype":"image/jpeg","size":"30000"}');
select public.seal_photo('00000000-0000-0000-0000-00000000000a/p2.jpg', null, null, null, 1600, 1200, true, '{}',
  null, '00000000-0000-0000-0000-00000000000a/p2_t.jpg');
select pg_temp.ok((select count(*)=2 from storage.objects where name like '%p2%'), 'owner can open the photo and its thumbnail');
do $$ begin
  begin perform public.seal_photo('00000000-0000-0000-0000-00000000000a/p2.jpg', null, null, null, null, null, false, '{}',
          null, '00000000-0000-0000-0000-00000000000b/x_t.jpg');
        raise exception 'FAIL: thumbnail from another folder accepted';
  exception when others then if sqlerrm like 'FAIL%' then raise; end if; raise notice 'pass: thumbnail must be in your own folder'; end;
end $$;
select pg_temp.as_user('00000000-0000-0000-0000-00000000000b');
select pg_temp.ok((select count(*)=2 from storage.objects where name like '%p2%'), 'section-mate opens the shared thumbnail too');
select pg_temp.as_user('00000000-0000-0000-0000-00000000000d');
select pg_temp.ok((select count(*)=0 from storage.objects), 'outsider cannot open thumbnails');

reset role;
update public.app_settings set max_items_per_minute = 6;
set role authenticated;
select pg_temp.as_user('00000000-0000-0000-0000-00000000000d');
do $$ declare k int; blocked int := 0; begin
  for k in 1..10 loop
    begin perform public.seal_note('spam ' || k);
    exception when others then blocked := blocked + 1; end;
  end loop;
  if blocked <> 4 then raise exception 'FAIL: per-minute limit blocked % of 10', blocked; end if;
  raise notice 'pass: per-minute limit stops floods';
end $$;
select pg_temp.ok((select count(*)=6 from public.capsule_items), 'exactly the allowed number got through');

reset role;
set role anon;
select pg_temp.ok((select sum(items)=3 from public.batch_stats()), 'stats are cached for a minute');
reset role;
update public.stats_cache set computed_at = now() - interval '2 minutes';
select pg_temp.ok((select sum(items) from public.batch_stats()) = (select count(*) from public.capsule_items), 'stats refresh after the minute is up');
reset role;

select 'ALL TESTS PASSED' as result;
