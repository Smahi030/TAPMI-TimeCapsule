#!/usr/bin/env bash
# Runs the security tests against a local Postgres (15+).
# Usage: PGHOST=localhost PGUSER=postgres ./tests/run_tests.sh
set -euo pipefail
cd "$(dirname "$0")/.."
DB=capsule_test
psql -v ON_ERROR_STOP=1 -q -c "drop database if exists $DB" -c "create database $DB"
psql -v ON_ERROR_STOP=1 -q -d $DB -f tests/supabase_stubs.sql
psql -v ON_ERROR_STOP=1 -q -d $DB -f supabase/migrations/20261027000000_init.sql
psql -v ON_ERROR_STOP=1 -q -d $DB -f supabase/seed.sql
psql -v ON_ERROR_STOP=1 -q -d $DB -f tests/rls_test.sql 2>&1 | grep -E "pass:|FAIL|ALL TESTS"
