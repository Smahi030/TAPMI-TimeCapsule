# TAPMI Time Capsule: backend and setup

The Batch of 2026–28 seals photos and notes during the MBA. Everything opens
together on **1 May 2028**. Until then nobody can read a sealed item, including
the person who sealed it.

```
tapmi-capsule/
  web/                     the website (static files, host anywhere)
    index.html             the page
    config.js              your Supabase URL and public key go here
  supabase/
    setup.sql              the whole database in one file (paste and run)
    migrations/…_init.sql  same database, for the Supabase CLI
    seed.sql               sections, clubs, places, events
    functions/
      delete-item/         removes an item and its photo files
      opening-day-email/   emails everyone once the capsule opens
  .github/workflows/
    keepalive.yml          stops a free project from pausing (optional)
  tests/                   security tests and the load test
```

With `config.js` left empty the page runs as a browser-only prototype. Fill it
in and the same page uses the real backend.

---

## How much it can handle

Tested on a copy of the database filled with **1,000 students and 50,000
memories** (30% shared with a section, 15% with a club), through PostgREST,
the same API layer Supabase uses, on a small 2-core machine:

| Test | Result |
|---|---|
| All 1,000 students open the site in the same second | every page loaded, no errors, last one in about 8 s |
| 100 people refreshing nonstop for 30 s | about 70 full page loads per second, no errors |
| 300 people sealing notes nonstop for 40 s | 6,116 seals, median 2 ms each, no errors, no duplicates |
| Database time for one page load | 10 ms (the first version took 715 ms on the same data) |

What makes that possible:

- **One fast query per page.** `my_capsule()` uses indexes to fetch a person's
  own items plus everything shared with their section or clubs, 60 cards at a
  time ("Show older memories" loads the next 60).
- **Thumbnails.** Each photo is resized on the phone before upload (1600 px,
  about 300 KB) and a 480 px thumbnail (about 35 KB) is uploaded with it. The
  grid loads thumbnails lazily; the full photo loads only when someone taps it.
- **Safe retries.** If a connection drops, the site retries with back-off.
  Sealing is idempotent (the browser picks the id), so a retry never creates a
  duplicate. Busy errors show "Wait a minute and try again", not a crash.
- **Limits.** 200 items per person and 40 per minute, so one person (or a
  script) can't flood the capsule. Both are settings you can change.
- **Cached counts.** The "memories sealed across the batch" line is
  recalculated at most once a minute.
- **Sign-in codes.** College email runs on Outlook, whose link scanner
  sometimes opens sign-in links before the student does, which uses them up.
  The email also carries a 6-digit code the student can type instead.

### What will run out first (and costs)

The database will not be the problem. Photo storage, bandwidth and email
will be:

| | Free plan | Pro plan ($25 a month) |
|---|---|---|
| Photo storage | 1 GB, about 2,500 photos | 100 GB, about 250,000 photos |
| Bandwidth | 5 GB a month | 250 GB a month |
| Pauses when quiet | after about a week | never |

A rough guide: if 600 people seal 30 photos each, that is 18,000 photos, about
7 GB. So start on the free plan, watch **Project Settings > Usage**, and
switch to Pro when storage passes about 800 MB, and in any case for opening
month (thousands of people viewing photos in the same week). Pro is about
₹2,100 a month at current exchange rates.

---

## Setting it up

You need about an hour. Do the steps in order.

### 1. Create the Supabase project
1. Sign up at supabase.com and create a project. Pick the **Mumbai**
   (ap-south-1) region so it's fast from Manipal.
2. Save the database password in a password manager. Don't send it to anyone,
   including me.

### 2. Create the database
1. Open **SQL Editor > New query**.
2. Paste the whole of `supabase/setup.sql` and press **Run**. It should end
   with "Success. No rows returned".
3. Check the student email domain. `learner.manipal.edu` is my guess; run this
   with the real one if it's different:
   ```sql
   update app_settings set allowed_email_domains = array['learner.manipal.edu'];
   ```

### 3. Set up email (required)
Supabase's built-in sender only reaches your own team, about 2 emails an hour.
The batch needs a real email service.

1. Make an account with an email provider. **Brevo** (300 emails a day free)
   or **Resend** (100 a day free; $20 a month for 50,000) both work.
   Verify a sender address or domain with them.
2. In Supabase: **Authentication > Emails > SMTP Settings**, turn on custom
   SMTP and paste the provider's host, port, username and password.
3. Daily caps matter on launch day. With a 300-a-day cap, open sign-ups
   section by section (two or three sections a day), or pay for one month
   of the provider's paid tier during launch. People stay signed in after
   their first sign-in, so after launch you need very few emails.

### 4. Sign-in settings
1. **Authentication > Emails > Templates.** Open **Magic Link** and replace
   the body with the text below. Do the same for **Confirm signup** (new
   users get that one the first time).
   ```html
   <h2>Your TAPMI Time Capsule sign-in</h2>
   <p>Your code: <strong style="font-size:22px;letter-spacing:3px">{{ .Token }}</strong></p>
   <p>Type it on the site, or tap this link on the same device:
      <a href="{{ .ConfirmationURL }}">Open my capsule</a></p>
   <p>If you didn't ask for this, ignore this email.</p>
   ```
   Subject: `Your TAPMI capsule code`
2. **Authentication > Rate Limits.** Everyone on campus Wi-Fi shares one
   internet address, and the default allows only 30 sign-ins per 5 minutes
   from one address. Raise these:
   - Sign-ups and sign-ins: **300** per 5 minutes
   - Token verifications: **300** per 5 minutes
   - Token refreshes: **1,000** per 5 minutes
   - Emails sent per hour: just under your email provider's limit
3. **Authentication > URL Configuration.** Leave this until step 7, once you
   know the website's address.

### 5. Deploy the two functions
Install the Supabase CLI (`npm i -g supabase`), then from this folder:

```bash
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase functions deploy delete-item
supabase functions deploy opening-day-email --no-verify-jwt
supabase secrets set RESEND_API_KEY=re_xxx \
  CAPSULE_FROM_EMAIL="TAPMI Time Capsule <capsule@yourdomain.com>" \
  CAPSULE_SITE_URL="https://your-site.pages.dev" \
  CRON_SECRET="any-long-random-string"
```

`delete-item` is needed for the delete button. `opening-day-email` is
optional and uses Resend's API. Skip its secrets if you don't want the email.

### 6. Schedule the opening-day email (optional)
**Database > Extensions**: turn on `pg_cron` and `pg_net`. Then in the SQL
Editor, with your project ref and the same secret:

```sql
select cron.schedule('opening-day-email', '*/15 * * * *', $$
  select net.http_post(
    url := 'https://YOUR_PROJECT_REF.supabase.co/functions/v1/opening-day-email',
    headers := jsonb_build_object('Content-Type','application/json','x-cron-secret','any-long-random-string'),
    body := '{}'::jsonb)
$$);
```

Before opening day it does nothing. From 1 May 2028 it sends 50 emails every
15 minutes until everyone has one, never anyone twice, and stops early if the
provider says "too many".

### 7. Put the website online
1. In **Project Settings > API**, copy the **Project URL** and the **anon
   public** key into `web/config.js`. The anon key is meant to be public;
   never put the `service_role` key anywhere in the website.
2. Upload the `web` folder to a host with a global CDN. Either:
   - **Cloudflare Pages**: Workers & Pages > Create > Pages > Upload assets.
   - **Netlify Drop**: drag the folder onto app.netlify.com/drop.

   Both are free and handle far more traffic than a batch can make.
3. Back in Supabase, **Authentication > URL Configuration**: set *Site URL*
   to the website's address and add the same address under *Redirect URLs*.

### 8. Keep it awake (free plan only)
Put this folder in a GitHub repository and add two repository secrets,
`SUPABASE_URL` and `SUPABASE_ANON_KEY`. The included workflow pings the
database twice a week so the project never pauses. Not needed on Pro.

### 9. Check it yourself
1. Open the site and sign in with your college email, once with the link
   and once with the code.
2. Finish your profile, seal a note and two photos, share one with your section.
3. In **Table Editor** you should see rows in `capsule_items`, and in
   **Storage > capsules** two files per photo (`…jpg` and `…_t.jpg`), while
   the site still shows everything sealed.
4. Ask a section-mate to sign in. They should see your shared card, sealed.

---

## What is in the database

| Table | What it holds | Who can read it |
|---|---|---|
| `app_settings` | opening date, email domain, limits | everyone |
| `sections`, `committees`, `places`, `events` | the lists on the site | everyone |
| `profiles` | name, college email, section (fixed once chosen) | only the person |
| `profile_committees` | which clubs each person is in | only the person |
| `capsule_items` | one row per note or photo: who, kind, place, event, dates. **No note text.** | the owner, plus anyone in a section or club it was shared with |
| `capsule_shares` | which section and clubs each item went to | the same people |
| `capsule_contents` | the note text | **nobody until 1 May 2028**, then the owner and everyone it was shared with |
| `stats_cache` | batch totals, refreshed each minute | nobody directly (through `batch_stats()`) |
| `opening_emails` | who got the opening email | nobody (server only) |
| storage bucket `capsules` | photos and thumbnails, private, 10 MB max | **nobody until 1 May 2028**, then the same people as the item |

How the lock holds:

- The opening date is stamped on each item by the server. Browsers can't
  choose it, so nobody can seal something "open now" to peek.
- Browsers can't write to tables. Sealing goes through `seal_note` and
  `seal_photo`, which check who is signed in.
- Only addresses on the allowed domain can sign up.
- Photos are private files. A viewing link can only be made after opening day
  by someone allowed to see that item.

### Sharing a group photo

When sealing, a person can tick **My section** and any of **their own clubs**.
Everyone in those groups gets it too, as a sealed card saying who it is from.

- Membership is checked when the capsule is read, so someone who joins a club
  later still gets that club's earlier photos.
- You can share only with your own section and clubs you are in.
- Your section is fixed once you pick it, so nobody can hop sections. An admin
  can fix a mistake (see below).
- Clubs are chosen by each person and not checked against a member list.
  Someone could tick a club they're not in and see that club's shared items
  after opening day.
- Only the person who sealed an item can delete it.

One honest limit: the lock stops students, not the project owner. Whoever
has the Supabase dashboard login can read the database. Tell the batch who
that is, and keep it to one or two trusted people.

---

## Admin cheat sheet (SQL Editor)

```sql
-- Fix someone's section
select admin_set_section('name@learner.manipal.edu', 'core-3');

-- Move opening day for everyone (e.g. once convocation is fixed)
select admin_set_open_date('2028-05-01 00:00+05:30');

-- Change limits
update app_settings set max_items_per_user = 300, max_items_per_minute = 60;

-- Add a club, place or event (also add it to the lists near the top of
-- the script in web/index.html: const COMMITTEES, PLACES, EVENTS)
insert into committees (id, name) values ('newclub', 'New Club');
insert into places (id, name, kind, descriptor) values ('malpe-pier','Malpe pier','off_campus',null);
insert into events (id, name, sort) values ('new-event','New event',8);

-- How much each section has sealed
select * from batch_stats();

-- Storage used so far
select pg_size_pretty(sum((metadata->>'size')::bigint)) from storage.objects where bucket_id = 'capsules';

-- Leftover photo files (upload worked, sealing didn't). Safe to delete.
select o.name from storage.objects o
where o.bucket_id = 'capsules'
  and not exists (select 1 from capsule_items i where i.storage_path = o.name or i.thumb_path = o.name);
```

---

## Running the tests

Security tests (68 checks), on any machine with Postgres 15 or newer:

```bash
PGHOST=localhost PGUSER=postgres ./tests/run_tests.sh
```

It ends with `ALL TESTS PASSED`.

Load test: load `tests/load/seed_1000_students.sql` into a test copy of the
database, run PostgREST against it, then
`node tests/load/load.js burst 1000 1 <jwt-secret>` (also `open` and `seal`
scenarios). Never point it at the real project.
