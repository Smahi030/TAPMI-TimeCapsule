// Deletes one of the signed-in user's capsule items, including its photo file.
// Needed because sealed photos are unreadable to everyone, owner included,
// so the browser cannot delete the file itself.
import { createClient } from "jsr:@supabase/supabase-js@2";
import { corsHeaders, json } from "../_shared/cors.ts";

const URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Use POST" }, 405);

  const authHeader = req.headers.get("Authorization") ?? "";
  const asUser = createClient(URL, ANON, { global: { headers: { Authorization: authHeader } } });
  const { data: { user } } = await asUser.auth.getUser();
  if (!user) return json({ error: "Sign in again to delete items" }, 401);

  let id: string | undefined;
  try { ({ id } = await req.json()); } catch { /* handled below */ }
  if (!id || !/^[0-9a-f-]{36}$/i.test(id)) return json({ error: "Missing item id" }, 400);

  const admin = createClient(URL, SERVICE);
  const { data: item, error: readErr } = await admin
    .from("capsule_items").select("id, owner_id, storage_path, thumb_path").eq("id", id).maybeSingle();
  if (readErr) return json({ error: "Could not look up that item" }, 500);
  if (!item || item.owner_id !== user.id) return json({ error: "Item not found" }, 404);

  const files = [item.storage_path, item.thumb_path].filter((f): f is string => !!f);
  if (files.length) {
    const { error } = await admin.storage.from("capsules").remove(files);
    if (error) return json({ error: "Could not delete the photo file, try again" }, 500);
  }
  const { error: delErr } = await admin.from("capsule_items").delete().eq("id", id);
  if (delErr) return json({ error: "Could not delete the item, try again" }, 500);

  return json({ deleted: id });
});
