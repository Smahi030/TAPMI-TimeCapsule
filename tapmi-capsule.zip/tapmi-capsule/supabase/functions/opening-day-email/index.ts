// Sends one "your capsule is open" email per person, once opening day arrives.
// Run it on a schedule (see README). It does nothing before open_at and never
// emails the same person twice. Uses Resend (https://resend.com) for sending.
import { createClient } from "jsr:@supabase/supabase-js@2";
import { corsHeaders, json } from "../_shared/cors.ts";

const URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND_KEY = Deno.env.get("RESEND_API_KEY");
const FROM = Deno.env.get("CAPSULE_FROM_EMAIL") ?? "TAPMI Time Capsule <capsule@example.com>";
const SITE = Deno.env.get("CAPSULE_SITE_URL") ?? "https://example.com";
const CRON_SECRET = Deno.env.get("CRON_SECRET");
// How many emails per run. Keep it under your email provider's per-minute limit.
const BATCH = Number(Deno.env.get("CAPSULE_EMAILS_PER_RUN") ?? "50");

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (!CRON_SECRET || req.headers.get("x-cron-secret") !== CRON_SECRET) {
    return json({ error: "Not allowed" }, 403);
  }
  if (!RESEND_KEY) return json({ error: "RESEND_API_KEY is not set" }, 500);

  const admin = createClient(URL, SERVICE);
  const { data: settings } = await admin.from("app_settings").select("open_at, batch_label").single();
  if (!settings || new Date(settings.open_at) > new Date()) {
    return json({ skipped: "Not opening day yet", open_at: settings?.open_at });
  }

  const { data: sent } = await admin.from("opening_emails").select("profile_id");
  const done = new Set((sent ?? []).map((r) => r.profile_id));
  const { data: people, error } = await admin
    .from("profiles").select("id, email, full_name").not("section_id", "is", null);
  if (error) return json({ error: error.message }, 500);

  const todo = (people ?? []).filter((p) => !done.has(p.id)).slice(0, BATCH);
  let ok = 0;
  for (const p of todo) {
    const first = (p.full_name ?? "").split(" ")[0] || "there";
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${RESEND_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: FROM,
        to: p.email,
        subject: "Your TAPMI capsule is open",
        text: `Hi ${first},\n\nThe ${settings.batch_label} capsule unlocked today. ` +
              `Everything you sealed between Induction and Convocation is waiting for you.\n\n` +
              `Open it: ${SITE}#vault\n\nSee you there.`,
      }),
    });
    if (res.ok) {
      await admin.from("opening_emails").insert({ profile_id: p.id });
      ok++;
    } else if (res.status === 429) {
      break; // provider limit reached; the next scheduled run carries on
    }
    await new Promise((r) => setTimeout(r, 250)); // stay under provider rate limits
  }
  return json({ sent: ok, remaining: Math.max(0, (people?.length ?? 0) - done.size - ok) });
});
