-- TAPMI Time Capsule: everything in one file.
-- Paste this whole file into Supabase > SQL Editor and press Run, once.
-- (Same as supabase/migrations/…_init.sql followed by supabase/seed.sql.)

-- =====================================================================
-- TAPMI Time Capsule: database schema
-- Batch of 2026-28. Every capsule opens together on 1 May 2028.
--
-- How the time lock works
--   * capsule_items holds what anyone may see while a capsule is sealed:
--     kind, caption, place, section, dates. No note text.
--   * capsule_contents holds the note text. Its read policy only passes
--     once the item's opens_at has gone by, so the owner cannot read it
--     early either, not even through the API.
--   * Photos live in the private "capsules" storage bucket. The read
--     policy on storage.objects checks the same opens_at, so signed URLs
--     cannot be created before opening day.
--   * opens_at is set on the server from app_settings. Clients never
--     choose it, so nobody can seal something "open now" to peek.
--   * Clients cannot insert rows directly. Sealing goes through the
--     seal_note / seal_photo functions, which check the signed-in user.
--
-- Sharing with a section or a club
--   * When sealing, the owner can tag their own section and any clubs or
--     committees they belong to (capsule_shares).
--   * Everyone currently in those groups sees the item as a sealed card in
--     their capsule straight away, including people who join later, and
--     can open it on opening day like their own.
--   * A person's section is fixed once set, so nobody can hop sections to
--     see another section's shared memories. Admins can change it.
--
-- Built for a whole batch at once
--   * The website reads its capsule through my_capsule(), one indexed query
--     per page of 60 cards, instead of filtering the whole table.
--   * Seals are idempotent (the browser picks the id), so a retry after a
--     dropped connection never creates a duplicate.
--   * Per-person limits: total items and items per minute.
--   * batch_stats() is cached for a minute, so every visitor loading the
--     page costs almost nothing.
--   * Photos are stored twice: a small thumbnail for the grid and the full
--     image, which loads only when someone taps a card.
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------
-- Settings (one row)
-- ---------------------------------------------------------------------
create table public.app_settings (
  id                    boolean primary key default true check (id),
  batch_label           text        not null default 'Batch of 2026–28',
  open_at               timestamptz not null default '2028-05-01 00:00:00+05:30',
  convocation_month     date        not null default '2028-03-01',
  allowed_email_domains text[]      not null default array['learner.manipal.edu'],
  max_items_per_user    int         not null default 200,
  max_note_length       int         not null default 5000,
  max_items_per_minute  int         not null default 40,
  updated_at            timestamptz not null default now()
);
insert into public.app_settings default values;

-- ---------------------------------------------------------------------
-- Reference data
-- ---------------------------------------------------------------------
create table public.sections (
  id    text primary key,
  name  text not null unique,
  sort  int  not null
);

create table public.committees (
  id    text primary key,
  name  text not null unique
);

create table public.events (
  id    text primary key,
  name  text not null unique,
  sort  int  not null default 100
);

create table public.places (
  id         text primary key,
  name       text not null unique,
  kind       text not null default 'campus' check (kind in ('campus','off_campus')),
  descriptor text,
  sort       int  not null default 100
);

-- ---------------------------------------------------------------------
-- People
-- ---------------------------------------------------------------------
create table public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  email       text not null,
  full_name   text check (char_length(full_name) between 1 and 80),
  section_id  text references public.sections(id),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index profiles_section_idx on public.profiles(section_id);

create table public.profile_committees (
  profile_id   uuid not null references public.profiles(id) on delete cascade,
  committee_id text not null references public.committees(id),
  primary key (profile_id, committee_id)
);

-- ---------------------------------------------------------------------
-- Capsules
-- ---------------------------------------------------------------------
create type public.capsule_kind as enum ('note','photo');

create table public.capsule_items (
  id            uuid primary key default gen_random_uuid(),
  owner_id      uuid not null references public.profiles(id) on delete cascade,
  kind          public.capsule_kind not null,
  owner_name    text,
  caption       text check (char_length(caption) <= 120),
  place_id      text references public.places(id),
  event_id      text references public.events(id),
  section_id    text references public.sections(id),
  storage_path  text unique,
  thumb_path    text unique,
  mime_type     text,
  width         int,
  height        int,
  bytes         int,
  sealed_at     timestamptz not null default now(),
  opens_at      timestamptz not null,
  check ((kind = 'photo') = (storage_path is not null))
);
create index capsule_items_owner_idx   on public.capsule_items(owner_id, sealed_at desc);
create index capsule_items_opens_idx   on public.capsule_items(opens_at);
create index capsule_items_event_idx   on public.capsule_items(event_id);
create index capsule_items_sealed_idx  on public.capsule_items(sealed_at desc, id desc);

-- Groups an item is shared with: one row per section or club
create table public.capsule_shares (
  item_id      uuid not null references public.capsule_items(id) on delete cascade,
  section_id   text references public.sections(id),
  committee_id text references public.committees(id),
  check ((section_id is null) <> (committee_id is null))
);
create unique index capsule_shares_section_uq   on public.capsule_shares(item_id, section_id)   where section_id is not null;
create unique index capsule_shares_committee_uq on public.capsule_shares(item_id, committee_id) where committee_id is not null;
create index capsule_shares_section_idx   on public.capsule_shares(section_id, item_id);
create index capsule_shares_committee_idx on public.capsule_shares(committee_id, item_id);
create index capsule_shares_item_idx      on public.capsule_shares(item_id);
create index profile_committees_comm_idx  on public.profile_committees(committee_id);

create table public.capsule_contents (
  item_id    uuid primary key references public.capsule_items(id) on delete cascade,
  note_text  text not null check (char_length(note_text) between 1 and 20000)
);

-- Cached batch-wide counts (refreshed at most once a minute)
create table public.stats_cache (
  section_id  text primary key references public.sections(id) on delete cascade,
  people      bigint not null default 0,
  items       bigint not null default 0,
  computed_at timestamptz not null default now()
);

-- Who has been sent the opening-day email
create table public.opening_emails (
  profile_id uuid primary key references public.profiles(id) on delete cascade,
  sent_at    timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------
create or replace function public.touch_updated_at() returns trigger
language plpgsql as $$
begin new.updated_at := now(); return new; end $$;

create trigger profiles_touch before update on public.profiles
  for each row execute function public.touch_updated_at();
create trigger settings_touch before update on public.app_settings
  for each row execute function public.touch_updated_at();

-- Can the current user see this item at all (metadata)?
create or replace function public.can_see_item(i public.capsule_items) returns boolean
language sql stable security definer set search_path = public as $$
  select auth.uid() is not null and (
       i.owner_id = auth.uid()
    or exists (
         select 1 from public.capsule_shares s
          where s.item_id = i.id and (
               (s.section_id is not null and s.section_id =
                  (select p.section_id from public.profiles p where p.id = auth.uid()))
            or (s.committee_id is not null and exists (
                  select 1 from public.profile_committees pc
                   where pc.profile_id = auth.uid() and pc.committee_id = s.committee_id))
          ))
  )
$$;

create or replace function public.can_see_item_id(item uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.capsule_items i where i.id = item and public.can_see_item(i))
$$;

-- Is this item open and visible to the current user (content)?
create or replace function public.can_open_item(item uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.capsule_items i
    where i.id = item and now() >= i.opens_at and public.can_see_item(i)
  )
$$;

-- Same check, keyed by storage path (used by the storage policy).
-- Works for both the full photo and its thumbnail.
create or replace function public.can_open_object(path text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.capsule_items i
    where (i.storage_path = path or i.thumb_path = path)
      and now() >= i.opens_at and public.can_see_item(i)
  )
$$;

-- Ids of every item shared with the current user's section or clubs.
-- Used by the security rules, evaluated once per query.
create or replace function public.shared_item_ids() returns setof uuid
language sql stable security definer set search_path = public as $$
  select s.item_id from public.capsule_shares s
   where s.section_id = (select p.section_id from public.profiles p where p.id = auth.uid())
  union
  select s.item_id from public.capsule_shares s
    join public.profile_committees pc on pc.committee_id = s.committee_id
   where pc.profile_id = auth.uid()
$$;

-- ---------------------------------------------------------------------
-- New sign-ups: enforce college email domain and create a profile
-- ---------------------------------------------------------------------
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  domains text[];
  dom     text := lower(split_part(coalesce(new.email,''), '@', 2));
begin
  select allowed_email_domains into domains from public.app_settings;
  if coalesce(array_length(domains,1),0) > 0
     and not (dom = any (select lower(d) from unnest(domains) d)) then
    raise exception 'Sign-ups are limited to college email addresses'
      using errcode = 'P0001';
  end if;
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, nullif(trim(new.raw_user_meta_data->>'full_name'), ''))
  on conflict (id) do nothing;
  return new;
end $$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------
-- Writes go through these functions only
-- ---------------------------------------------------------------------
create or replace function public.complete_profile(
  p_full_name text, p_section_id text, p_committee_ids text[] default '{}'
) returns public.profiles
language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); result public.profiles; current_section text;
begin
  if uid is null then raise exception 'Not signed in'; end if;
  if p_section_id is null or not exists (select 1 from public.sections where id = p_section_id) then
    raise exception 'Choose a valid section';
  end if;
  select section_id into current_section from public.profiles where id = uid;
  if current_section is not null and current_section <> p_section_id then
    raise exception 'Your section is already set. Ask an admin to change it.';
  end if;
  update public.profiles
     set full_name = trim(p_full_name), section_id = p_section_id
   where id = uid
  returning * into result;
  if result.id is null then raise exception 'Profile not found'; end if;
  delete from public.profile_committees where profile_id = uid;
  insert into public.profile_committees (profile_id, committee_id)
    select uid, c from unnest(coalesce(p_committee_ids,'{}')) c
    where c in (select id from public.committees)
  on conflict do nothing;
  return result;
end $$;

create or replace function public._seal_guard(uid uuid) returns public.profiles
language plpgsql security definer set search_path = public as $$
declare prof public.profiles; lim int; per_min int; n int;
begin
  if uid is null then raise exception 'Not signed in'; end if;
  -- one seal at a time per person, so the limits below are exact
  perform pg_advisory_xact_lock(hashtextextended(uid::text, 7));
  select * into prof from public.profiles where id = uid;
  if prof.section_id is null then raise exception 'Finish your profile before sealing anything'; end if;
  select max_items_per_user, max_items_per_minute into lim, per_min from public.app_settings;
  select count(*) into n from public.capsule_items where owner_id = uid;
  if n >= lim then raise exception 'Capsule is full (% items)', lim; end if;
  select count(*) into n from public.capsule_items
   where owner_id = uid and sealed_at > now() - interval '1 minute';
  if n >= per_min then raise exception 'That is a lot at once. Wait a minute and try again.'; end if;
  return prof;
end $$;

-- Records who an item is shared with. Only your own section, and only clubs you are in.
create or replace function public._apply_shares(
  p_item uuid, p_uid uuid, p_section text, p_share_section boolean, p_share_committees text[]
) returns void
language plpgsql security definer set search_path = public as $$
declare c text;
begin
  if coalesce(p_share_section, false) then
    insert into public.capsule_shares (item_id, section_id) values (p_item, p_section);
  end if;
  foreach c in array coalesce(p_share_committees, '{}') loop
    if not exists (select 1 from public.profile_committees where profile_id = p_uid and committee_id = c) then
      raise exception 'You can only share with clubs and committees you are part of';
    end if;
    insert into public.capsule_shares (item_id, committee_id) values (p_item, c) on conflict do nothing;
  end loop;
end $$;

create or replace function public.seal_note(
  p_note text, p_caption text default null, p_place_id text default null, p_event_id text default null,
  p_share_section boolean default false, p_share_committees text[] default '{}',
  p_id uuid default null
) returns public.capsule_items
language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); prof public.profiles; item public.capsule_items; maxlen int;
begin
  -- a retry of a seal that already went through returns the same item
  if p_id is not null then
    select * into item from public.capsule_items where id = p_id;
    if item.id is not null then
      if item.owner_id is distinct from uid then raise exception 'That item id is taken'; end if;
      return item;
    end if;
  end if;
  prof := public._seal_guard(uid);
  select max_note_length into maxlen from public.app_settings;
  if p_note is null or char_length(trim(p_note)) = 0 then raise exception 'Write something first'; end if;
  if char_length(p_note) > maxlen then raise exception 'Notes can be up to % characters', maxlen; end if;
  if p_place_id is not null and not exists (select 1 from public.places where id = p_place_id) then
    raise exception 'Unknown place';
  end if;
  if p_event_id is not null and not exists (select 1 from public.events where id = p_event_id) then
    raise exception 'Unknown event';
  end if;
  insert into public.capsule_items (id, owner_id, owner_name, kind, caption, place_id, event_id, section_id, opens_at)
  values (coalesce(p_id, gen_random_uuid()), uid, prof.full_name, 'note', nullif(trim(p_caption),''), p_place_id, p_event_id, prof.section_id,
          (select open_at from public.app_settings))
  returning * into item;
  insert into public.capsule_contents (item_id, note_text) values (item.id, p_note);
  perform public._apply_shares(item.id, uid, prof.section_id, p_share_section, p_share_committees);
  return item;
end $$;

create or replace function public.seal_photo(
  p_storage_path text, p_caption text default null, p_place_id text default null, p_event_id text default null,
  p_width int default null, p_height int default null,
  p_share_section boolean default false, p_share_committees text[] default '{}',
  p_id uuid default null, p_thumb_path text default null
) returns public.capsule_items
language plpgsql security definer set search_path = public, storage as $$
declare uid uuid := auth.uid(); prof public.profiles; item public.capsule_items; obj storage.objects;
begin
  if p_id is not null then
    select * into item from public.capsule_items where id = p_id;
    if item.id is not null then
      if item.owner_id is distinct from uid then raise exception 'That item id is taken'; end if;
      return item;
    end if;
  end if;
  prof := public._seal_guard(uid);
  if p_storage_path is null or split_part(p_storage_path, '/', 1) <> uid::text then
    raise exception 'Photos must be uploaded to your own folder';
  end if;
  select * into obj from storage.objects
   where bucket_id = 'capsules' and name = p_storage_path;
  if obj.id is null then raise exception 'Upload the photo before sealing it'; end if;
  if p_thumb_path is not null then
    if split_part(p_thumb_path, '/', 1) <> uid::text or p_thumb_path = p_storage_path
       or not exists (select 1 from storage.objects where bucket_id = 'capsules' and name = p_thumb_path) then
      raise exception 'Thumbnail upload missing';
    end if;
  end if;
  if p_place_id is not null and not exists (select 1 from public.places where id = p_place_id) then
    raise exception 'Unknown place';
  end if;
  if p_event_id is not null and not exists (select 1 from public.events where id = p_event_id) then
    raise exception 'Unknown event';
  end if;
  insert into public.capsule_items (id, owner_id, owner_name, kind, caption, place_id, event_id, section_id,
                                    storage_path, thumb_path, mime_type, width, height, bytes, opens_at)
  values (coalesce(p_id, gen_random_uuid()), uid, prof.full_name, 'photo', nullif(trim(p_caption),''), p_place_id, p_event_id, prof.section_id,
          p_storage_path, p_thumb_path, obj.metadata->>'mimetype', p_width, p_height,
          nullif(obj.metadata->>'size','')::int,
          (select open_at from public.app_settings))
  returning * into item;
  perform public._apply_shares(item.id, uid, prof.section_id, p_share_section, p_share_committees);
  return item;
end $$;

-- Batch-wide counts. Shows how much was sealed, never what.
-- Recomputed at most once a minute; every other call reads the cache.
create or replace function public.batch_stats()
returns table (section_id text, section_name text, people bigint, items bigint)
language plpgsql volatile security definer set search_path = public as $$
begin
  if not exists (select 1 from public.stats_cache where computed_at > now() - interval '60 seconds')
     and pg_try_advisory_xact_lock(4242) then
    insert into public.stats_cache as c (section_id, people, items, computed_at)
    select s.id, count(distinct i.owner_id), count(i.id), now()
      from public.sections s
      left join public.capsule_items i on i.section_id = s.id
     group by s.id
    on conflict on constraint stats_cache_pkey do update
      set people = excluded.people, items = excluded.items, computed_at = excluded.computed_at;
  end if;
  return query
    select s.id, s.name, coalesce(c.people, 0), coalesce(c.items, 0)
      from public.sections s left join public.stats_cache c on c.section_id = s.id
     order by s.sort;
end $$;

-- The signed-in person's profile, clubs and item count in one call
create or replace function public.my_profile() returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'full_name',  p.full_name,
    'section_id', p.section_id,
    'committees', coalesce((select jsonb_agg(pc.committee_id order by pc.committee_id)
                              from public.profile_committees pc where pc.profile_id = p.id), '[]'::jsonb),
    'my_items',   (select count(*) from public.capsule_items i where i.owner_id = p.id))
    from public.profiles p where p.id = auth.uid()
$$;

-- One page of the signed-in person's capsule: their own items plus
-- everything shared with their section or clubs, newest first.
-- Note text is included only once the item has opened.
-- Page through with the sealed_at and id of the last card.
create or replace function public.my_capsule(
  p_limit int default 60, p_before timestamptz default null, p_before_id uuid default null
) returns table (
  id uuid, owner_id uuid, owner_name text, kind public.capsule_kind, caption text,
  place_id text, event_id text, section_id text, storage_path text, thumb_path text,
  opens_at timestamptz, sealed_at timestamptz, shared_with text[], note_text text
)
language sql stable security definer set search_path = public as $$
  with me as (
    select p.id as uid, p.section_id as sec from public.profiles p where p.id = auth.uid()
  ), ids as (
    select i.id from public.capsule_items i, me where i.owner_id = me.uid
    union
    select s.item_id from public.capsule_shares s, me where s.section_id = me.sec
    union
    select s.item_id from public.capsule_shares s
      join public.profile_committees pc on pc.committee_id = s.committee_id
      join me on pc.profile_id = me.uid
  )
  select i.id, i.owner_id, i.owner_name, i.kind, i.caption, i.place_id, i.event_id, i.section_id,
         i.storage_path, i.thumb_path, i.opens_at, i.sealed_at,
         coalesce((select array_agg(coalesce('section:' || s.section_id, 'club:' || s.committee_id))
                     from public.capsule_shares s where s.item_id = i.id), '{}'),
         case when now() >= i.opens_at then c.note_text end
    from ids
    join public.capsule_items i on i.id = ids.id
    left join public.capsule_contents c on c.item_id = i.id
   where p_before is null
      or (i.sealed_at, i.id) < (p_before, coalesce(p_before_id, 'ffffffff-ffff-ffff-ffff-ffffffffffff'::uuid))
   order by i.sealed_at desc, i.id desc
   limit least(greatest(coalesce(p_limit, 60), 1), 200)
$$;

-- Admin only: change someone's section (sections are otherwise fixed once set)
create or replace function public.admin_set_section(p_email text, p_section_id text) returns void
language plpgsql security definer set search_path = public as $$
begin
  update public.profiles set section_id = p_section_id where lower(email) = lower(p_email);
  if not found then raise exception 'No profile with that email'; end if;
end $$;

-- Admin only: move opening day for everyone (run from the SQL editor)
create or replace function public.admin_set_open_date(p_open_at timestamptz) returns void
language plpgsql security definer set search_path = public as $$
begin
  update public.app_settings set open_at = p_open_at;
  update public.capsule_items set opens_at = p_open_at;
end $$;

-- ---------------------------------------------------------------------
-- Row level security
-- ---------------------------------------------------------------------
alter table public.app_settings       enable row level security;
alter table public.sections           enable row level security;
alter table public.committees         enable row level security;
alter table public.places             enable row level security;
alter table public.events             enable row level security;
alter table public.profiles           enable row level security;
alter table public.profile_committees enable row level security;
alter table public.capsule_items      enable row level security;
alter table public.capsule_contents   enable row level security;
alter table public.capsule_shares     enable row level security;
alter table public.opening_emails     enable row level security;
alter table public.stats_cache        enable row level security;

create policy "settings readable" on public.app_settings for select using (true);
create policy "sections readable" on public.sections for select using (true);
create policy "committees readable" on public.committees for select using (true);
create policy "places readable" on public.places for select using (true);
create policy "events readable" on public.events for select using (true);

create policy "read own profile" on public.profiles
  for select to authenticated using (id = (select auth.uid()));
create policy "read own committees" on public.profile_committees
  for select to authenticated using (profile_id = (select auth.uid()));

-- (select auth.uid()) and the set-returning helper are evaluated once per
-- query, not once per row, which keeps these fast on a big table.
create policy "see own and shared items" on public.capsule_items
  for select to authenticated
  using (owner_id = (select auth.uid()) or id in (select public.shared_item_ids()));
create policy "delete own items" on public.capsule_items
  for delete to authenticated using (owner_id = (select auth.uid()));

create policy "see shares of visible items" on public.capsule_shares
  for select to authenticated
  using (item_id in (select public.shared_item_ids())
         or item_id in (select i.id from public.capsule_items i where i.owner_id = (select auth.uid())));

create policy "read content once open" on public.capsule_contents
  for select to authenticated
  using (item_id in (select i.id from public.capsule_items i where now() >= i.opens_at));

-- Table privileges: read through RLS, write only through functions
revoke all on all tables in schema public from anon, authenticated;
grant select on public.app_settings, public.sections, public.committees, public.places, public.events to anon, authenticated;
grant select on public.profiles, public.profile_committees, public.capsule_items, public.capsule_shares, public.capsule_contents to authenticated;
grant delete on public.capsule_items to authenticated;

revoke execute on all functions in schema public from public, anon, authenticated;
grant execute on function public.complete_profile(text, text, text[]) to authenticated;
grant execute on function public.seal_note(text, text, text, text, boolean, text[], uuid) to authenticated;
grant execute on function public.seal_photo(text, text, text, text, int, int, boolean, text[], uuid, text) to authenticated;
grant execute on function public.batch_stats() to anon, authenticated;
grant execute on function public.my_profile() to authenticated;
grant execute on function public.my_capsule(int, timestamptz, uuid) to authenticated;
grant execute on function public.shared_item_ids() to authenticated;
grant execute on function public.can_see_item(public.capsule_items) to authenticated;
grant execute on function public.can_see_item_id(uuid) to authenticated;
grant execute on function public.can_open_item(uuid) to authenticated;
grant execute on function public.can_open_object(text) to authenticated;
-- admin_set_open_date, admin_set_section, _seal_guard and _apply_shares stay
-- callable only by the service role / SQL editor

-- ---------------------------------------------------------------------
-- Storage: private bucket for photos, 10 MB, images only
-- Paths are <user id>/<random id>.<ext>
-- ---------------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('capsules', 'capsules', false, 10485760, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

create policy "upload to own folder" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'capsules' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "read photo once open" on storage.objects
  for select to authenticated
  using (bucket_id = 'capsules' and public.can_open_object(name));


-- Photo files are deleted by the delete-item edge function (service role),
-- because a sealed photo is unreadable to its owner and Postgres only lets
-- you delete rows you can read. Notes can be deleted directly.

-- Reference data for the Batch of 2026-28. Safe to run more than once.

insert into public.sections (id, name, sort) values
  ('core-1','Core 1',1), ('core-2','Core 2',2), ('core-3','Core 3',3),
  ('core-4','Core 4',4), ('core-5','Core 5',5), ('msm','MSM',6),
  ('ib','IB',7), ('bkfs','BKFS',8), ('hr','HR',9), ('ai-ds','AI&DS',10)
on conflict (id) do update set name = excluded.name, sort = excluded.sort;

insert into public.committees (id, name) values
  ('arc','ARC'), ('atharva','Atharva'), ('brandscan','BrandScan'), ('brats','Brats'),
  ('cct','CCT'), ('cultcom','CultCom'), ('hoa','HOA'), ('lime','Lime'),
  ('logcom','LogCom'), ('omega','Omega'), ('ops-forum','Ops Forum'), ('pace','PACE'),
  ('samnidhy','Samnidhy'), ('sec','SEC'), ('sportscom','SportsCom'), ('taf','TAF'),
  ('tff','TFF'), ('tmf','TMF'), ('toastmasters','Toastmasters'), ('treasury','Treasury'),
  ('welfare','Welfare'), ('ytbn','YTBN')
on conflict (id) do update set name = excluded.name;

insert into public.places (id, name, kind, descriptor, sort) values
  ('sus-block','SUS Block','campus','block',1),
  ('nc','NC','campus','night canteen',2),
  ('verde','Verde','off_campus','tapri just outside campus',3),
  ('swathi','Swathi','off_campus','bar, 10 min by auto',4),
  ('library','Library','campus',null,5),
  ('hostel','Hostel','campus',null,6),
  ('malpe','Malpe','off_campus','beach',7)
on conflict (id) do update set name = excluded.name, kind = excluded.kind,
  descriptor = excluded.descriptor, sort = excluded.sort;

insert into public.events (id, name, sort) values
  ('induction','Induction',1), ('case-comps','Case comps',2), ('waves','Waves',3),
  ('speed','SPEED',4), ('atharva','Atharva',5), ('internship','Summer internship',6),
  ('convocation','Convocation',7)
on conflict (id) do update set name = excluded.name, sort = excluded.sort;
