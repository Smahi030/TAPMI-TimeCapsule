-- Reference data for the Batch of 2026-28. Safe to run more than once.

insert into public.sections (id, name, sort) values
  ('core-1','Core 1',1), ('core-2','Core 2',2), ('core-3','Core 3',3),
  ('core-4','Core 4',4), ('core-5','Core 5',5), ('msm','MSM',6),
  ('ib','IB',7), ('bkfs','BKFS',8), ('hr','HR',9), ('ai-ds','AI&DS',10)
on conflict (id) do update set name = excluded.name, sort = excluded.sort;

insert into public.committees (id, name) values
  ('arc','ARC'), ('atharva','Atharva'), ('brandscan','BrandScan'), ('brats','Brats'),
  ('cct','CCT'), ('cultcom','CultCom'), ('hoa','HOA'), ('lime','Lime'),
  ('logcom','LogCom'), ('omega','Omega'), ('ops-forum','Ops Forum'), ('pace','PACE'),
  ('samnidhy','Samnidhy'), ('sec','SEC'), ('sportscom','SportsCom'), ('taf','TAF'),
  ('tff','TFF'), ('tmf','TMF'), ('toastmasters','Toastmasters'), ('treasury','Treasury'),
  ('welfare','Welfare'), ('ytbn','YTBN')
on conflict (id) do update set name = excluded.name;

insert into public.places (id, name, kind, descriptor, sort) values
  ('sus-block','SUS Block','campus','block',1),
  ('nc','NC','campus','night canteen',2),
  ('verde','Verde','off_campus','tapri just outside campus',3),
  ('swathi','Swathi','off_campus','bar, 10 min by auto',4),
  ('library','Library','campus',null,5),
  ('hostel','Hostel','campus',null,6),
  ('malpe','Malpe','off_campus','beach',7)
on conflict (id) do update set name = excluded.name, kind = excluded.kind,
  descriptor = excluded.descriptor, sort = excluded.sort;

insert into public.events (id, name, sort) values
  ('induction','Induction',1), ('case-comps','Case comps',2), ('waves','Waves',3),
  ('speed','SPEED',4), ('atharva','Atharva',5), ('internship','Summer internship',6),
  ('convocation','Convocation',7)
on conflict (id) do update set name = excluded.name, sort = excluded.sort;
